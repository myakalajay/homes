import React,{useEffect,useState} from "react";
import { useDispatch, useSelector } from 'react-redux';
import { FaUserEdit, FaKey, FaCertificate, FaUniversity, FaUserTie } from 'react-icons/fa';
import Licenses from "./Licenses";
import Lender from "./Lender";
import Broker from "./Broker";
import Lodashmain from "./Lodashmain";
import  Link  from 'next/link';
import Step from "@/page/Step";
import Loscenarios from "./Loscenarios";
import Lopreapproval from "./Lopreapproval";
import Dashloantracker from "./Dashloantracker";
import RefinanceTracker from "./RefinanceTracker";

const Lodashboard = () => {
    const [expanded, setExpanded] = useState(true);
    const [loexpand, setLoExpand] = useState(true); // Set default to true
    const [modalShow, setModalShow] = React.useState(false);
    const [dashname, setDashName] = useState([]);
    const [activeTab, setActiveTab] = useState('lo-Dashboard');
    const isLoggedIn = useSelector(state => state.auth.isLoggedIn);
    const firstname = useSelector(state => state.auth.firstname);
    const [exploreModalShow, setExploreModalShow] = React.useState(false);
    const dispatch = useDispatch();
    const handleTabChange = (tab) => {
        setActiveTab(tab);
        // setExpanded(true); // Expand all buttons on any tab click
        setLoExpand(true); // Ensure buttons are expanded when changing tabs
    }
    const toggleExpand = () => {
        setLoExpand(!loexpand);
    }



    return (
        <>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-2 col-sm-12 p-3 mt-4">
                    </div>
                    <div className="col-sm-12 col-md-12 d-flex">
                    <div className="nav nav-pills">
                            <div className="nav-item" style={{ marginTop: "100px" }}>
                            <button
                                    className={`toggle-expand-btn ${loexpand ? 'expanded' : ''}`}
                                    onClick={toggleExpand}
                                >
                                    {/* {loexpand && '<<' : '>>'} */}
                                    {loexpand ? <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5"/>
</svg>:<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
</svg>}
                                </button>
                                <button 
                                    className={`dash-but ${loexpand ? 'expanded' : ''} ${activeTab === 'lo-Dashboard' ? 'active' : ''}`} 
                                    onClick={() => handleTabChange('lo-Dashboard')}
                                >
                                    <FaUserEdit  style={{ marginRight: '10px' }}/> 
                                    {loexpand && <span>Dashboard</span>}
                                </button>

                                <button 
                                    className={`dash-but ${loexpand ? 'expanded' : ''} ${activeTab === 'Scenario' ? 'active' : ''}`} 
                                    onClick={() => handleTabChange('Scenario')}
                                >
                                    <FaKey style={{ marginRight: '10px' }}/> 
                                    {loexpand && <span>Your Scenario's</span>}
                                </button>

                                <button 
                                    className={`dash-but ${loexpand ? 'expanded' : ''} ${activeTab === 'Approved' ? 'active' : ''}`} 
                                    onClick={() => handleTabChange('Approved')}
                                >
                                    <FaCertificate style={{ marginRight: '10px' }}/> 
                                    {loexpand && <span>Pre Approved Letters</span>}
                                </button>

                                <button 
                                    className={`dash-but ${loexpand ? 'expanded' : ''} ${activeTab === 'Licenses' ? 'active' : ''}`} 
                                    onClick={() => handleTabChange('Licenses')}
                                >
                                    <FaUniversity style={{ marginRight: '10px' }}/> 
                                    {loexpand && <span>Licenses</span>}
                                </button>

                                <button 
                                    className={`dash-but ${loexpand ? 'expanded' : ''} ${activeTab === 'Lender-Information' ? 'active' : ''}`} 
                                    onClick={() => handleTabChange('Lender-Information')}
                                >
                                    <FaUserTie style={{ marginRight: '10px' }}/> 
                                    {loexpand && <span>Lender Information</span>}
                                </button>
                                <button 
                                    className={`dash-but ${loexpand ? 'expanded' : ''} ${activeTab === 'Broker-Information' ? 'active' : ''}`} 
                                    onClick={() => handleTabChange('Broker-Information')}
                                >
                                    <FaUserTie style={{ marginRight: '10px' }}/> 
                                    {loexpand && <span>Broker Information</span>}
                                </button>
                                <button 
                                    className={`dash-but ${loexpand ? 'expanded' : ''} ${activeTab === 'Loan' ? 'active' : ''}`} 
                                    onClick={() => handleTabChange('Loan')}
                                >
                                    <FaUserTie style={{ marginRight: '10px' }}/> 
                                    {loexpand && <span>Loan Tracker</span>}
                                </button>
                                <button 
                                    className={`dash-but ${loexpand ? 'expanded' : ''} ${activeTab === 'Refinance' ? 'active' : ''}`} 
                                    onClick={() => handleTabChange('Refinance')}
                                >
                                    <FaUserTie style={{ marginRight: '10px' }}/> 
                                    {loexpand && <span>Refinance Tracker</span>}
                                </button>
                            </div>
                        </div>
                        <div className="tab-content dashboard-background">
                        <div className="col-md-12 col-sm-12 m-2">
            <div className='col-md-12 p-3 dash-card2 d-flex' style={{ marginTop: "100px" }}>
                    <img src="./assets/images/home-page/Dashcard-img.png" alt="" className="dash-img"/>                   
                    <div className="mx-3">
                    <p>{isLoggedIn ?`HI, ${firstname}`: 'HI'}</p>
                    
                    <p> Congratulations! Your mortgage loan has been approved.Review and sign the final<br/> documents to<Link href="#"> Procced</Link></p>
                    <button className="dashboard-explore-button" onClick={() => setExploreModalShow(true)}>
                                        EXPLORE YOUR HOME LOAN OPTIONS
                                        </button>

                                        {/* commneted for testing purpose */}
                                        <Step
                                        show={exploreModalShow}
                                        onHide={() => setExploreModalShow(false)}
                                        />
                   
                    </div>
                   {/* <div>
                    <button className="dashboard-button mt-5"  onClick={() => handlePropertyTypeClick(null)}>Add property</button>
                   <br/>
                    <button className='dashboard-button1 mt-2'>Add Loan</button>
                    </div> */}
                    
                    
                    
                    </div>
                   
                  
            </div>
                            <div id="lo-Dashboard" className={`tab-pane ${activeTab === 'lo-Dashboard' ? 'active' : 'fade'}`} >
                                <div className="col-sm-12 col-md-12 p-3 d-flex justify-content-between">
                                </div>
                                <div className="mx-2">
                                <div className="col-sm-12 col-md-12 mx-2 m-1 d-flex justify-content-between">
                                    <div>
                                        <span className="dashhome-text">Home
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
                                            </svg>
                                        </span>
                                        <span className="dashhome-text">Dashboard</span>
                                        <h4 className="dashmain-head"> Summary</h4>
                                    </div>
                                </div>
            <div className="col-sm-12 col-md-12 m-2">
        <div className="dash-card">
        {/* <div className="d-flex justify-content-between">
                  <h4 className="p-3">Overview</h4>
                <div className="p-3">
                  <button className="btn btn-light mx-2">
                    {Array.isArray(dashname) && dashname.length > 0 ? (
                                    dashname.map((dash) => (
                                        <p key={dash.year} value={dash.month}>
                                            {dash.month !== null ? dash.month : "No data available"}
                                        </p>
                                    ))
                                ) : (
                                    <p>No data available</p>
                                )}month
                                </button>
                  <button className="btn btn-light">Year</button>
                </div>
                </div> */}
                
                <div className="">
                <h5 className="mx-1">Your Overview</h5>
                </div>
            <div className="d-flex">
            <div className="dashboard-card">
                    <span className="dash-text" onClick={() => handleTabChange('Scenario')}> User Scenarios</span>
                    <div className="pt-1 px-1">
                    <h6>  
                                {Array.isArray(dashname) && dashname.length > 0 ? (
                                    dashname.map((dash) => (
                                        <p className="pt-2" key={dash.year} value={dash.totalvalue}>
                                            <img src="./assets/images/icons/dash-card2.svg" alt="" />
                                            {dash.totalvalue !== null ? dash.totalvalue : "No data available"}
                                        </p>
                                    ))
                                ) : (
                                    <p><img src="./assets/images/icons/dash-card2.svg" alt="" />No data available</p>
                                )}
                                </h6>
                    </div>
                    <div className="dash-text">
                        Avg up by
                        <span className="dash-text px-4">+12%</span>
                    </div>
                </div>
                <div className="dashboard-card">
                    <span className="dash-text" onClick={() => handleTabChange('Approved')}>Pre Approved Request</span>
                    <div className="pt-2 px-1">
                     <h6>
                                 {Array.isArray(dashname) && dashname.length > 0 ? (
                                    dashname.map((dash) => (
                                        <p key={dash.year} value={dash.propcount}>
                                            <img src="./assets/images/icons/dashboard-card1.svg" alt="" />
                                            {dash.propcount !== null ? dash.propcount : "No data available"}
                                        </p>
                                        // <p key={dash.year}>{dash.propcount !== null ? dash.propcount : 'No data available'}</p>
                                    ))
                                ) : (
                                    <p> <img src="./assets/images/icons/dashboard-card1.svg" alt="" />No data available</p>
                                )}
                                </h6>
                    </div>
                    <div className="dash-text">
                        Avg up by
                        <span className="dash-text px-4">+12%</span>
                    </div>
                </div>
               
                <div className="dashboard-card">
                    <span className="dash-text" onClick={() => handleTabChange('Loan')}>Loan In Progress</span>
                    <div className="pt-2 px-1">
                    <h6>
                    {Array.isArray(dashname) && dashname.length > 0 ? (
                                    dashname.map((dash) => (
                                        <p key={dash.year} value={dash.outstandingloan}>
                                             <img src="./assets/images/icons/dash-card3.svg" alt="" />
                                            {dash.outstandingloan !== null ? dash.outstandingloan : "No data available"}
                                        </p>
                                    ))
                                ) : (
                                    <p> <img src="./assets/images/icons/dash-card3.svg" alt="" />No data available</p>
                                )}
                    </h6>
                    </div>
                    
                    <div className="dash-text">
                        Avg up by
                        <span className="dash-text px-4">+12%</span>
                    </div>
                </div>
                <div className="dashboard-card">
                    <span className="dash-text" onClick={() => handleTabChange('Approved')}>Outstanding Invoices</span>
                    <div className="pt-2 px-1">
                     <h6>
                                 {Array.isArray(dashname) && dashname.length > 0 ? (
                                    dashname.map((dash) => (
                                        <p key={dash.year} value={dash.propcount}>
                                            <img src="./assets/images/icons/dashboard-card1.svg" alt="" />
                                            {dash.propcount !== null ? dash.propcount : "No data available"}
                                        </p>
                                        // <p key={dash.year}>{dash.propcount !== null ? dash.propcount : 'No data available'}</p>
                                    ))
                                ) : (
                                    <p> <img src="./assets/images/icons/dashboard-card1.svg" alt="" />No data available</p>
                                )}
                                </h6>
                    </div>
                    <div className="dash-text">
                        Avg up by
                        <span className="dash-text px-4">+12%</span>
                    </div>
                </div>
                {/* <div className="dashboard-card">
                    <span className="dash-text" onClick={() => handleTabChange('Approved')}>Pre Approval Letters Iss</span>
                    <div className="pt-2 px-1">
                     <h6>
                                 {Array.isArray(dashname) && dashname.length > 0 ? (
                                    dashname.map((dash) => (
                                        <p key={dash.year} value={dash.propcount}>
                                            <img src="./assets/images/icons/dashboard-card1.svg" alt="" />
                                            {dash.propcount !== null ? dash.propcount : "No data available"}
                                        </p>
                                        // <p key={dash.year}>{dash.propcount !== null ? dash.propcount : 'No data available'}</p>
                                    ))
                                ) : (
                                    <p> <img src="./assets/images/icons/dashboard-card1.svg" alt="" />No data available</p>
                                )}
                                </h6>
                    </div>
                    <div className="dash-text">
                        Avg up by
                        <span className="dash-text px-4">+12%</span>
                    </div>
                </div> */}
                </div>
                </div>
                </div>  
                <Lodashmain />
                                </div>
                            </div>
                            <div id="Scenario" className={`tab-pane ${activeTab === 'Scenario' ? 'active' : 'fade'}`}>
                                <div className="col-sm-12 col-md-12 p-3 d-flex justify-content-between">
                                    <div>
                                    <Link href="/"style={{textDecoration:"none"}}><span className="dashhome-text">Home
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
                                            </svg>
                                          
                                        </span></Link>
                                        <span className="dashhome-text">Your-Scenario</span>
                                        <h4 className="dashmain-head">Your-Scenario</h4>
                                    </div>
                                </div>
                                <div className="dash-head-card mx-2">
                                    <Loscenarios />     
                                </div>
                            </div>
                            <div id="Approved" className={`tab-pane ${activeTab === 'Approved' ? 'active' : 'fade'}`} >
                                <div className="col-sm-12 col-md-12 p-3 d-flex justify-content-between">
                                    <div>
                                    <Link href="/"style={{textDecoration:"none"}}><span className="dashhome-text">Home
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
                                            </svg>
                                        </span></Link>
                                        <span className="dashhome-text">Pre Approved Letters</span>
                                        <h4 className="dashmain-head">Pre Approved Letters</h4>
                                    </div>
                                </div>
                                <div className="dash-head-card dash-table p-2 mx-2">
                                    <Lopreapproval/>     
                                </div>
                            </div>
                            <div id="Licenses" className={`tab-pane ${activeTab === 'Licenses' ? 'active' : 'fade'}`} >
                                <div className="col-sm-12 col-md-12 p-3 d-flex justify-content-between">
                                    <div>
                                        <Link href="/"style={{textDecoration:"none"}}><span className="dashhome-text">Home
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
                                            </svg>
                                        </span></Link>
                                        <span className="dashhome-text">Licenses </span>
                                        <h4 className="dashmain-head">Licenses </h4>
                                    </div>
                                </div>
                                <div className="dash-head-card dash-table mx-2">
                                    <Licenses />
                                </div>
                            </div>  
                            <div id="Lender-Information" className={`tab-pane ${activeTab === 'Lender-Information' ? 'active' : 'fade'}`}>
                                <div className="col-sm-12 col-md-12 p-3 d-flex justify-content-between">
                                    <div>
                                    <Link href="/"style={{textDecoration:"none"}}><span className="dashhome-text">Home
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
                                            </svg>
                                        </span></Link>
                                        <span className="dashhome-text">Lender Information</span>
                                        <h4 className="dashmain-head">Lender Information</h4>
                                    </div>
                                </div>
                                <div className="dash-head-card dash-table p-2 mx-2">
                                    <Lender />
                                </div>
                            </div> 
                            <div id="Broker-Information" className={`tab-pane ${activeTab === 'Broker-Information' ? 'active' : 'fade'}`}>
                                <div className="col-sm-12 col-md-12 p-3 d-flex justify-content-between">
                                    <div>
                                    <Link href="/"style={{textDecoration:"none"}}><span className="dashhome-text">Home
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
                                            </svg>
                                        </span></Link>
                                        <span className="dashhome-text">Broker Information</span>
                                        <h4 className="dashmain-head">Broker Information</h4>
                                    </div>
                                </div>
                                <div className="dash-head-card dash-table mx-2">
                                    <Broker />
                                </div>
                            </div>
                            <div id="Loan" className={`tab-pane ${activeTab === 'Loan' ? 'active' : 'fade'}`}>
                                <div className="col-sm-12 col-md-12 p-3 d-flex justify-content-between">
                                    <div>
                                    <Link href="/"style={{textDecoration:"none"}}><span className="dashhome-text">Home
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
                                            </svg>
                                        </span></Link>
                                        <span className="dashhome-text">Loan-Tracker</span>
                                        <h4 className="dashmain-head">Loan-Tracker</h4>
                                    </div>
                                </div>
                                <div className="dash-head-card dash-table mx-2">
                                    <Dashloantracker />
                                </div>
                            </div>
                            <div id="Refinance" className={`tab-pane ${activeTab === 'Refinance' ? 'active' : 'fade'}`}>
                                <div className="col-sm-12 col-md-12 p-3 d-flex justify-content-between">
                                    <div>
                                    <Link href="/"style={{textDecoration:"none"}}><span className="dashhome-text">Home
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708"/>
                                            </svg>
                                        </span></Link>
                                        <span className="dashhome-text">Refinance Tracker</span>
                                        <h4 className="dashmain-head">Refinance Tracker</h4>
                                    </div>
                                </div>
                                <div className="dash-head-card dash-table mx-2">
                                  <RefinanceTracker/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Lodashboard;
