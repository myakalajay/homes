import React,{useEffect, useState} from 'react'
import { useRouter } from 'next/router';

export default function Pdf() {

    const router = useRouter();
    const { data } = router.query;
    const [formData, setFormData] = useState(null);
    const [showTextField, setShowTextField] = useState(false);
    const [brokerNames, setBrokerNames] = useState([]);
    const [selectedBroker, setSelectedBroker] = useState(null);
    const [showMultipleBorrowers, setShowMultipleBorrowers] = useState(false);


    useEffect(() => {
        if (data) {
          const parsedData = JSON.parse(data);
          setFormData(parsedData);
        }
      }, [data]);

    useEffect(() => {
        const fetchBrokername = async () => {
            const requestData = { broker: "" };
              // console.log('Request Data:', requestData);
          try {
            const response = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/getbroker`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                // Add any other headers as needed
              },
              body: JSON.stringify(requestData),
            });
            if (!response.ok) {
                throw new Error('Network response was not ok');
              }
           
            const data = await response.json();
            setBrokerNames(data);
            //  console.log('setdata',data)
          } catch (error) {
            console.error('Error fetching data:', error);
          }
        };
        fetchBrokername();
          }, []);

    const handleChangeYes = (event) => {
      if (event.target.value === 'yes') {
        setShowTextField(true);
      } else {
        setShowTextField(false);
      }
    };

    // const handleBrokerChange = (event) => {
    //     const brokerName = event.target.value;
    //     const selected = brokerNames.find(broker => broker.brokername === brokerName);
    //     setSelectedBroker(selected || null);
    // };

    const handleBrokerChange = (event) => {
        const brokerName = event.target.value;
        const selected = brokerNames.find(broker => broker.brokername === brokerName);
        setSelectedBroker(selected || null);
        setFormData((prevData) => ({
          ...prevData,
          brokerName: brokerName,
          address: selected?.address || '',  // Assuming broker data contains an address
          nmlsId: selected?.companynmls || '',
          websiteLink: selected?.website || ''
        }));
      };

    // const handleBorrowerTypeChange = (event) => {
    //     setShowMultipleBorrowers(event.target.value === 'multiple');
    //   };
    
    const handleBorrowerTypeChange = (event) => {
        const value = event.target.value;
        setShowMultipleBorrowers(value === 'multiple');
        setFormData((prevData) => ({
          ...prevData,
          borrowers: value,
        }));
      };

      const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
          ...prevData,
          [name]: value,
        }));
      };

      const generatePDF = () => {
        const previewMessage = document.getElementById('previewMessage');
        previewMessage.contentEditable = false;  // Make the entire div non-editable initially
    
        previewMessage.innerHTML = `
          <p>BORROWER Name: <span>${formData.brokerName || ''}</span></p>
          <p>Address: <span contenteditable="true" style="border: none; outline: none;">${formData.address || ''}</span></p>
          <p>NMLS ID: <span>${formData.nmlsId || ''}</span></p>
          <p>Website: <span contenteditable="true" style="border: none; outline: none;">${formData.websiteLink || ''}</span></p>
          <p>Borrower 1: <span contenteditable="true" style="border: none; outline: none;">${formData.borrowerfullname1 || ''}</span></p>
          ${showMultipleBorrowers ? `<p>Borrower 2: <span contenteditable="true" style="border: none; outline: none;">${formData.borrowerfullname2 || ''}</span></p>` : ''}
          <p>Property Address: <span contenteditable="true" style="border: none; outline: none;">${formData.propertyaddress || ''}</span></p>
          <p>State: <span contenteditable="true" style="border: none; outline: none;">${formData.state || ''}</span></p>
          <p>Transaction Type: <span contenteditable="true" style="border: none; outline: none;">${formData.transactiontype || ''}</span></p>
          <p>Property Type: <span contenteditable="true" style="border: none; outline: none;">${formData.propertytype || ''}</span></p>
          <p>Occupancy: <span contenteditable="true" style="border: none; outline: none;">${formData.occupancytype || ''}</span></p>
          <p>Purchase Price: <span contenteditable="true" style="border: none; outline: none;">${formData.purchasePrice || ''}</span></p>
          <p>Loan Program: <span contenteditable="true" style="border: none; outline: none;">${formData.loanProgram || ''}</span></p>
          <p>Down Payment: <span contenteditable="true" style="border: none; outline: none;">${formData.downPayment || ''}</span></p>
          <p>Loan Amount: <span contenteditable="true" style="border: none; outline: none;">${formData.loanAmount || ''}</span></p>
          <p>LTV: <span contenteditable="true" style="border: none; outline: none;">${formData.LTV || ''}</span></p>
          <p>Doc Type: <span contenteditable="true" style="border: none; outline: none;">${formData.doctype || ''}</span></p>
          <p>Message: <span contenteditable="true" style="border: none; outline: none;">${formData.message || ''}</span></p>
          <p>Congratulations! You’ve taken the first step towards home ownership. Your request for the above specified loan has been prequalified based on gainful income (DTI< 43%) and great assets. Please NOTE that loan commitment will depend on ratified pending contract and compliance with following underwriting guidelines. A written commitment to make the loan has not yet been issued.</p>
         <h5>PRIOR TO CLOSING</h5>
         <ul>
            <li>SATISFIED FLOOD CERTIFICATION ORDER BY LENDER</li>
            <li>SATISFIED TITLE WORK</li>
            <li>LIABILITY INSURANCE FOR PUD REQUIRED</li>
            <li>APPRAISAL REPORT</li>
         </ul>
         <h5>AT THE CLOSING</h5>
         <ul>
            <li>HOMEOWNER’S INSURANCE BINDER</li>
            <li>TITLE BINDER SURVEY AND TAXES</li>
            <li>CERTIFICATION OF OCCUPANCY IF REQUIRED</li>
            <li>PUD CERTIFICATION IF REQUIRED </li>
         </ul>
         <p>your signature</p>
         <h5>Mortgage Loan Originator</h5>
         <p>NMLS Number:</p>
         <h5>${formData.brokerName || ''}</h5>
         <h5>Pre-approval is subject to review and final approval by underwriting. Additional conditions may be required. If the borrower's information or the requested terms change, this pre-qualification may be void. NMLS ID :${formData.nmlsId || ''}</h5>
         <h5>Before we issue preapproval and Final approval the following are needed.</h5> 
         <p>1. Fully executed Purchase Agreement.</p>
        <p>2. Satisfactory appraisal supporting property purchase amount.</p>
        <p>3. Home Owners Insurance to cover loan amount with 100% replacement coverage.</p>
        <p>4. Title Insurance including 12-month chain of title.</p>
        <p>5. Most recent income documentation to be verified.</p>
        <p>6. Documentation of acceptable funds to close.</p>
         `;
    };
    
    
    


      const sendTestMail = async () => {
        const previewMessage = document.getElementById('previewMessage').innerHTML;
    
        const cleanMessage = previewMessage.replace(/<p>/g, '').replace(/<\/p>/g, '').replace(/<h5>/g, '').replace(/<\/h5>/g, '').replace(/<ul>/g, '').replace(/<\/ul>/g, '').replace(/<li>/g, '').replace(/<\/li>/g, '');


        const requestData = {
          previewMessage:cleanMessage,
        };
    
        try {
          const response = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/sendTestMail`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestData),
          });
    
          if (!response.ok) {
            throw new Error('Failed to send test mail');
          }
    
          alert('Test mail sent successfully!');
        } catch (error) {
          console.error('Error sending test mail:', error);
          alert('Failed to send test mail.');
        }
      };
    

      if (!formData) {
        return <div>Loading...</div>;
      }

    
    return (
    <div className="container conven-page d-flex">
        <div className="form-section p-3">
            <span className='head-background'>Broker Information</span>
            <div className="form-group">
                <label htmlFor="brokerName">Broker Name</label>
                <select id="brokerName" name="brokerName" onChange={handleBrokerChange}>
                    <option value="">Select Broker</option>
                    {brokerNames.map(broker => (
                        <option key={broker.brokerid} value={broker.brokername}>
                            {broker.brokername}
                        </option>
                    ))}
                </select>
            </div>

            <div className="form-group">
                <label htmlFor="address">Address</label>
                <input
                    type="text"
                    id="address"
                    name="address"
                    placeholder="Address"
                    value={selectedBroker ? selectedBroker.website : ''}
                    readOnly // Assuming address is not present in broker data, adjust as needed
                />
            </div>
            <div className="form-group">
                <label htmlFor="nmlsId">NMLS ID</label>
                <input
                    type="text"
                    id="nmlsId"
                    name="nmlsId"
                    placeholder="NMLS ID"
                    value={selectedBroker ? selectedBroker.companynmls : ''}
                    readOnly
                />
            </div>
            <div className="form-group">
                <label htmlFor="websiteLink">Website Link</label>
                <input
                    type="text"
                    id="websiteLink"
                    name="websiteLink"
                    placeholder="Website Link"
                    value={selectedBroker ? selectedBroker.website : ''}
                    // readOnly
                />
            </div>
            <span className='head-background'>Borrower Information Section</span>
            {/* <div className="radio-group">
                <label><input type="radio" name="borrowerType" value="single" onclick="toggleBorrowerFields()" checked/> Single Borrower</label>
                <label><input type="radio" name="borrowerType" value="multiple" onclick="toggleBorrowerFields()"/> Multiple Borrowers</label>
            </div> */}
                <div className='form-group'>
                  <div className='d-flex'>
                  <input
                    type="radio"
                    className='first-name'
                    label="No"
                    name="borrowers"
                    value="no"
                    checked={!showMultipleBorrowers}
                    onChange={handleBorrowerTypeChange}
                    // checked={formData.borrowers === 'no'}
                    // onChange={(e) => {
                    //   handleChange(e);
                    //   handleChangeYes(e);
                    // }}
                  />
                   <label>Single Borrower</label>
                  </div>
                  </div>
                  <div className='form-group'>
                  <div className='d-flex'>
                  <input
                    type="radio"
                    className='first-name'
                    label="Yes"
                    name="borrowers"
                    value="yes"
                    checked={showMultipleBorrowers}
                    onChange={handleBorrowerTypeChange}
                    // checked={formData.borrowers === 'yes'}
                    // onChange={(e) => {
                    //   handleChange(e);
                    //   handleChangeYes(e);
                    // }}
                  />
                  <label>Multiple Borrowers</label>
                  </div>
                </div>
        
            <div className="form-group">
                <label for="borrowerfullname1">Borrower First Name</label>
                <input 
                type="text" 
                id="borrowerfullname1" 
                name="borrowerfullname1"
                placeholder="First Name"
                value={formData.borrowerfullname1?.split(' ')[0] || ''}
                onChange={handleInputChange}
            />
            </div>
            <div className="form-group">
                <label for="borrowerfullname1">Borrower Last Name</label>
                <input 
                type="text" 
                id="borrowerfullname1" 
                name="borrowerfullname1" 
                placeholder="Last Name"
                value={formData.borrowerfullname1?.split(' ')[1] || ''}
                onChange={handleInputChange}
                />
            </div>
            
            {showMultipleBorrowers  && (
                <>
            {/* <div className="borrower-info"> */}
                {/* <h3>Additional Borrower Information</h3> */}
                <div className="form-group">
                    <label for="borrowerfullname2">Additional Borrower First Name</label>
                    <input 
                    type="text" 
                    id="borrowerfullname2" 
                    name="borrowerfullname2" 
                    placeholder="First Name"
                    value={formData.borrowerfullname2?.split(' ')[0] || ''}
                    onChange={handleInputChange}
                    />
                </div>
                <div className="form-group">
                    <label for="borrowerfullname2">Additional Borrower Last Name</label>
                    <input 
                    type="text" 
                    id="borrowerfullname2" 
                    name="borrowerfullname2" 
                    placeholder="Last Name"
                    value={formData.borrowerfullname2?.split(' ')[1] || ''}
                    onChange={handleInputChange}
                    />
                </div>
            {/* </div> */}
            </>
                )}
            <div className="form-group">
                <label for="propertyaddress">Property Address</label>
                <input 
                type="text" 
                id="propertyaddress" 
                name="propertyaddress" 
                placeholder="Property Address"
                value={formData.propertyaddress || ''}
                onChange={handleInputChange}
                />
            </div>
            <div className="form-group">
                <label for="state">State</label>
                <select 
                id="state" 
                name="state"
                value={formData.state || ''}
                onChange={handleInputChange}>
                    <option value="">Select a State</option>
                    <option value="AL">Alabama</option>
                    <option value="AK">Alaska</option>
                    <option value="AZ">Arizona</option>
                    <option value="AR">Arkansas</option>
                    <option value="CA">California</option>
                    <option value="CO">Colorado</option>
                </select>
            </div>
            
            <span className='head-background'>Transaction Details Section</span>
            <div className="form-group">
                <label for="transactiontype">Transaction Type</label>
                <select 
                id="transactiontype" 
                name="transactiontype"
                value={formData.transactiontype || ''}
                onChange={handleInputChange}>
                    <option value="">Select Type</option>
                    <option value="Purchase">Purchase</option>
                    <option value="Refinance">Refinance</option>
                    <option value="Equity">Equity</option>
                    <option value="Heloc">Heloc</option>
                </select>
            </div>
            
            <div className="form-group">
                <label for="propertytype">Property Type</label>
                <select 
                id="propertytype" 
                name="propertytype"
                value={formData.propertytype || ''}
                onChange={handleInputChange}>
                    <option value="">Select Type</option>
                    <option value="Single">Single</option>
                    <option value="Family">Family</option>
                    <option value="Town Home">Town Home</option>
                    <option value="Cando">Cando</option>
                </select>
            </div>
            <div className="form-group">
                <label for="occupancytype">Occupancy</label>
                <select id="occupancytype" name="occupancytype"
                value={formData.occupancytype || ''}
                onChange={handleInputChange}>
                    <option value="">Select Type</option>
                    <option value="Primary">Primary</option>
                    <option value="Secondary">Secondary</option>
                    <option value="Investment">Investment</option>
                </select>
            </div>
            <span className='head-background'>Loan Information Section</span>
            <div className="form-group">
                <label for="purchasePrice">Purchase Price Up to</label>
                <input 
                type="text" 
                id="purchasePrice" 
                name="purchasePrice" 
                placeholder="Purchase Price"
                />
            </div>
            <div className="form-group">
                <label for="term">Loan Program</label>
                <select id="term" name="term" 
                value={formData.term || ''}
                onChange={handleInputChange}>
                    <option value="">Select Type</option>
                    <option value="15">15 years</option>
                    <option value="20">20 years</option>
                    <option value="25">25 years</option>
                    <option value="30">30 years</option>
                </select>
            </div>
            <div className="form-group">
                <label for="downPayment">Down Payment</label>
                <input 
                type="text" 
                id="downPayment" 
                name="downPayment" 
                placeholder="Down Amount"
                value={formData.downpaypercent || ''}
                onChange={handleInputChange}
                />
            </div>
            <div className="form-group">
                <label for="loanAmount">Loan Amount</label>
                <input 
                type="text" 
                id="loanAmount" 
                name="loanAmount" 
                placeholder="Loan Amount"
                value={formData.loanamountpercent || ''}
                onChange={handleInputChange}
                />
            </div>
            <div className="form-group">
                <label for="LTV">LTV</label>
                <input 
                type="text" 
                id="LTV" 
                name="LTV" 
                placeholder="LTV"/>
            </div>
            <div className="form-group">
                <label for="doctype">Doc Type</label>
                <select 
                id="doctype" 
                name="doctype"
                value={formData.doctype || ''}
                onChange={handleInputChange} 
                >
                    <option value="">Select Type</option>
                    <option value="Full">Full</option>
                </select>
            </div>
            <span className='head-background'>Pre Qualification Notice Section</span>
            <div className="form-group">
                <label for="message">Message</label>
                <textarea 
                id="message" 
                name="message" 
                placeholder="Message" 
                oninput="updatePreview()"
                value={formData.message || ''}
                onChange={handleInputChange}></textarea>
            </div>n
            <div className="pdf-button-container">
                <a href="#" className="send-button" onClick={generatePDF}>Generate PDF</a>
            </div>

        </div>
        <div className="preview-section mt-3">
            <h2>Preview</h2>
            <div className="preview-box">
                <p style={{marginTop:"950px"}} id="previewMessage">MESSAGE </p>
            </div>
            <a href="#" className="send-button" onClick={sendTestMail}>Send Test Mail</a>
        </div>
    </div>
      )
}
