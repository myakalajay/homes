import React from 'react';

function Dashrates() {
  // const location = useLocation();
  const { rates } = location.state || {};

  return (
    <div>
      <h1>Rates Information</h1>
      {rates ? (
        <div>
          {/* Display rates information */}
          <p>Rate 1: {rates.path}</p>
          <p>Rate 2: {rates.location}</p>
          {/* Add other rates or information as needed */}
        </div>
      ) : (
        <p>No rates available</p>
      )}
    </div>
  );
}

export default Dashrates;

