import React,{useState} from "react";
import DOMPurify from 'dompurify';


function ChangePassword(){
    const [passwordData, setPasswordData] = useState({
        oldPassword: "",
        newPassword: "",
        // comfirmpassword:"",
    });

    const sanitizeInput = (value) => {
        return DOMPurify.sanitize(value);
    };

    const handlePasswordChange = (e) => {
        const { name, value } = e.target;
        const sanitizedValue = sanitizeInput(value);
        setPasswordData((prevData) => ({
            ...prevData,
            [name]: sanitizedValue,

        }));
    };


    // const handleSubmitPassword = async () => {
    //     try {
    //         const response = await fetch('${process.env.NEXT_API_URL}/api/v1/auth/changePassword', {
    //             method: 'POST',
    //             headers: {
    //                 'Content-Type': 'application/json',
    //             },
    //             body: JSON.stringify(passwordData),
    //         });

    //         if (!response.ok) {
    //             throw new Error('Network response was not ok');
    //         }

    //         const data = await response.json(); // Assuming the response contains JSON data
    //         console.log(data); // Handle success response
    //     } catch (error) {
    //         console.error(error); // Handle error
    //     }
    // };


    
    return(
        <>
        <div className="pt-3 px-3">
            <span className="profile-name ">Old Password</span>
            <div>
                <input 
                type="password" 
                className="dashboard-text" 
                name="oldPassword" 
                value={passwordData.oldPassword} 
                onChange={handlePasswordChange}
                />
            </div>
        </div>
        <div className="mt-3 px-3">
            <span className="profile-name">New Password</span>
            <div>
                <input 
                type="password" 
                className="dashboard-text"  
                name="newPassword" 
                value={passwordData.newPassword} 
                onChange={handlePasswordChange}
                />
            </div>
        </div>
        <div className="mt-3 px-3">
            <span className="profile-name">Confirm Password</span>
            <div>
                <input 
                type="password" 
                className="dashboard-text"   
                name="comfirmpassword" 
                value={passwordData.comfirmpassword} 
                onChange={handlePasswordChange}
                />
            </div>
        </div>
        <div>
            <button type="submit" className="lobutton m-4" >Save</button>
        </div>
        </>
    );
}

export default ChangePassword;