import React, { useEffect, useState } from "react";
import DOMPurify from 'dompurify';
import { useSelector } from "react-redux";

function Editprofile() {
    
   const [profileData, setProfileData] = useState([]);
    const [userData, setUserData] = useState([]);
    const [dataSaved, setDataSaved]=useState("");
    const token = useSelector(state => state.auth.token);
    const userid = useSelector(state => state.auth.userid);
    const usertype = useSelector(state => state.user.usertype);

    
    const sanitizeInput = (value) => {
        return DOMPurify.sanitize(value);
    };

    const handleProfileChange = (e) => {
        const { name, value } = e.target;
        const sanitizedValue = sanitizeInput(value);
        setProfileData((prevData) => ({
            ...prevData,
            [name]: sanitizedValue,
        }));
    };

    useEffect(() => {
        async function fetchData() {
            try {
                const response = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/getuserprofile`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ usertype: usertype, user: userid }),
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const data = await response.json(); // Assuming the response contains JSON data
                const user= data.result_sets[0][0];
                setProfileData(user); // Directly set the fetched data to profileData state
                console.log("getData", profileData); // Handle success response
                console.log("getData", user.firstname,user.lastname,user.email);
                console.log("getData",  data.result_sets[0][0]);
                console.log("getData",  data);
            } catch (error) {
                console.error(error); // Handle error
            }
        }
        fetchData();
    }, [usertype, userid]);

    const handleSmsAllowedChange = (value) => {
        setProfileData((prevData) => ({
            ...prevData,
            smsallowed: value === 'Yes' ? 1 : 0,
        }));
    };

    const payloadextra = {
        firstname: profileData.firstname,
        lastname: profileData.lastname,
        token: token,
        userid: userid,
        usertype: usertype,
        email: profileData?.emailaddress,
        whatsapp: profileData?.whatsapp,
        mobile: profileData?.mobile,
        work: profileData?.work,
        smsallowed: profileData?.smsallowed,
        username:profileData.emailaddress,
        passowrd:'',
        oauth:'0',
        social:false,

    };

    console.log("profileData",profileData)

  
    const handleSubmitProfile = async () => {
        try {
            const response = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/setuserprofile`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({  ...payloadextra }),
            });
            console.log("payloadextra", { ...payloadextra })

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json(); // Assuming the response contains JSON data
            setDataSaved("Profile updated successfully"); // Handle success response
            console.log("Editeddata", data); // Handle success response
        } catch (error) {
            console.error(error); // Handle error
        }
    };

    return (
        <>
        <div className="row p-3">
            <div className="col-sm-12 col-md-4">
            <div className="fName">
                                 <label style={{ "width": "83px", "height": "24px", "gap": "0px", "opacity": "0px" }}>First Name</label>
                                 <input
                                     type="text"
                                     className="dashboard-box"
                                     id="firstname"
                                     name="firstname"
                                     value={profileData?.firstname}
                                     onChange={handleProfileChange}
                                 />
                             </div>
            </div>
            <div className="col-sm-12 col-md-4">
            <div className="fName">
                                <label style={{ "width": "83px", "height": "24px", "gap": "0px", "color": "#083A50", "opacity": "0px" }}>Last Name</label>
                                <input
                                    type="text"
                                    className="dashboard-box"
                                    id="lastname"
                                    name="lastname"
                                    value={profileData?.lastname}
                                    onChange={handleProfileChange}
                                 />
                            </div>
            </div>
            <div className="col-sm-12 col-md-4">
            <div className="whatsapp">
                      <label style={{ "width": "4415px", "height": "20px", "color": "#083A50" }}>Email </label>
                        <input
                           type="text"
                           className="dashboard-box"
                           id="emailaddress"
                           name="emailaddress"
                           value={profileData?.emailaddress}
                           onChange={handleProfileChange}
                       />
                   </div>
            </div>
            <div className="col-sm-12 col-md-4">
            <div className="whatsapp">
                       <label style={{ "width": "114px", "height": "24px", "color": "#083A50","marginTop":"10px" }}>Phone Number</label>
                       <input
                           type="text"
                           className="dashboard-box"
                           id="mobile"
                           name="mobile"
                           value={profileData?.mobile}
                           onChange={handleProfileChange}
                       />
                   </div>
            </div>
            <div className="col-sm-12 col-md-4">
            <div className="whatsapp">
                            <label style={{ "width": "150px", "height": "24px", "color": "#083A50","marginTop":"10px" }}>Whatsapp Number</label>
                            <input
                                type="text"
                                className="dashboard-box"
                                id="whatsappnum"
                                name="whatsappnum"
                                value={profileData?.whatsappnum}
                                onChange={handleProfileChange}
                            />
                        </div>
                        </div>
                        <div className="col-sm-12 col-md-4">
                        <div className="whatsapp">
                            <label style={{ "width": "105px", "height": "24px", "color": "#083A50","marginTop":"10px" }}>Work Number</label>
                            <input
                                type="text"
                                className="dashboard-box"
                                id="worknumber"
                                name="worknumber"
                                value={profileData?.worknumber}
                                onChange={handleProfileChange}
                            />
                        </div>
            </div>
            <div className="col-sm-12 col-md-12 mt-2">
            <div className="sms">
                <div className="d-flex">
                    <div>
                            <label style={{ "width": "102px", "height": "20px", "color": "#083A50","marginTop":"10px" }}>SMS Allowed</label>
                                        <div>
                                        <input
                                            type="radio"
                                            label='Yes'
                                            value='Yes'
                                            style={{
                                                width: "22px",
                                                height: "14px",
                                                top: "12.5px",
                                                left: "34px",
                                                marginTop: "5px",
                                                gap: "0px",
                                                opacity: "0px"
                                            }}
                                            checked={profileData?.smsallowed }
                                            onChange={(e) => handleSmsAllowedChange(e.target.value)}
                                        />
                                        <label style={{ paddingLeft: "5px" }}>Yes</label>
                                        <input
                                            type='radio'
                                            label='No'
                                            value='No'
                                            style={{
                                                width: "22px",
                                                height: "14px",
                                                top: "12.5px",
                                                left: "120px",
                                                gap: "0px",
                                                marginTop: "5px",
                                                opacity: "0px",
                                            }}
                                            checked={profileData?.smsallowed === 0}
                                            onChange={(e) => handleSmsAllowedChange(e.target.value)}
                                        />
                                        <label style={{ paddingLeft: "5px" }}>No</label>
                                        </div>
                                    </div>
                                    </div>
                        </div>
            </div>
            <div className="col-sm-12 col-md-12">
                <div className="mt-3" style={{display:"flex"}}>
                <button className="lobutton profile-button text-centre" style={{marginBottom:"10px"}} onClick={handleSubmitProfile}>Save</button>
                {dataSaved && <div style={{alignContent:"center",color:"green"}}>{dataSaved}</div>}
            </div>
            </div>
        </div>
        </>
    )
}

export default Editprofile;
