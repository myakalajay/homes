import React from 'react'
// import "./style.css"
const PropertyDefault = () => {
  return (
    <div className='property-default'>
        <div className='text-wrapper'>Apply Now</div>
      
    </div>
  )
}

export default PropertyDefault
