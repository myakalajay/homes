import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import { useSelector } from 'react-redux';
import Chart from 'chart.js/auto';

const RatesGraph = () => {
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const zipcode = useSelector(state=> state.zipcode || '');

  useEffect(() => {
   fetchData();
 }, [zipcode]);

  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_SITE_URL}/getgraphrates`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ zipcode })
      });
      const jsonData = await response.json();
      setData(jsonData);
      setError(null);
    } catch (error) {
      setError(error.message);
    }
  };
  return (
    <div>
      {error && <p>Error: {error}</p>}
      {data.length > 0 && (
        <Line data={{
          labels: data.map((item) => item.product), 
          datasets: [
            {
              label: 'CONV Rate',
            data: data.map((item) => item.rate),
              borderColor: 'rgba(75, 192, 192, 1)',
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
            },
            {
              label: 'FHA Rate',
              data: data.map((item) => item.rate),
              borderColor: 'rgba(255, 99, 132, 1)',
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
            }
          ],
        }} 
        options={{
          scales: {
            yAxes: [
              {
                ticks: {
                  beginAtZero: true,
                },
              },
            ],
          },
        }}
        />
      )}
      
    </div>
  );
};

export default RatesGraph;
