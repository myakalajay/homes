import React, { useState, useEffect } from 'react';

export default function EMITable({jsonData}) {
    console.log(typeof(jsonData));
    return (
        <div>
            {jsonData && (
                <table className="table table-dark">
                    <thead>
                        <tr>
                            <th scope="col">Product</th>
                            <th scope="col">Ratetype</th>
                            <th scope="col">Rate</th>
                            <th scope="col">Monthly EMI(Principal+Interest)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {jsonData.map((row, rowIndex) => (
                            <tr key={rowIndex}>
                                <td>{row.product}</td>
                                <td>{row.ratetype}</td>
                                <td>{row.rate}</td>
                                <td>{row.monthpayment}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
    </div>
)

}