
import React, { useState, useEffect } from 'react';
import { PieChart } from 'react-minimal-pie-chart';

const PieChartGraph = ({ chartData, chartShape, updatePieChart }) => {
    const [data, setData] = useState([]);
    const [updateSignal, setUpdateSignal] = useState(false);

    const updateChartData = () => {
        if (chartData && chartData.length > 0) {
            const totalInterestPayment = parseFloat(chartData[0]?.totalinterestpayment);
            const totalPayment = parseFloat(chartData[0]?.totalpayment);

            if (!isNaN(totalInterestPayment) && !isNaN(totalPayment)) {
                setData([
                    { title: 'Total Interest Payment', value: totalInterestPayment, color: '#E38627' },
                    { title: 'Total Payment', value: totalPayment, color: '#C13C37' },
                ]);
            } else {
                console.error('Invalid data for pie chart:', chartData);
                setData([]);
            }
        } else {
            console.error('No data available for pie chart:', chartData);
            setData([]);
        }
    };

    
    useEffect(() => {
        updateChartData();
    }, [chartData, chartShape, updateSignal]);
    
    const updateChart = () => {
        setUpdateSignal(prevSignal => !prevSignal);
    };

    const calculateFontSize = () => {
        return chartShape === 'circle' ? '5px' : '4px'; 
    };

    return (
        <div className="pie-chart-container" style={{ width: '45%', height: '45%',margin:"0 auto" }}>
            {data.length > 0 ? (
                <>
                    <PieChart
                        data={data}
                        label={({ dataEntry }) => `${dataEntry.title}: ${dataEntry.value.toFixed(2)}`}
                        labelStyle={{
                            fontSize: calculateFontSize(),
                            fontFamily: 'Arial, sans-serif', 
                            fill: '#fff',
                        }}
                        reveal={true} 
                    />
                </>
            ) : (
                <div className="no-data-message">No data available for the pie chart.</div>
            )}
        </div>
    );
};

export default PieChartGraph;

