import React from "react";
import  { CircularProgressbar, buildStyles }  from 'react-circular-progressbar';
import { Table } from 'react-bootstrap';

const Affordabilitynav = ({ monthlyPayment, loanAmount, affordableHomeValue, downPayment }) => {
    const loanPercentage = loanAmount && affordableHomeValue ? (loanAmount / affordableHomeValue) * 100 : 0;
    const downPaymentPercentage = downPayment && affordableHomeValue ? (downPayment / affordableHomeValue) * 100 : 0;
    return (
        <>
            <div className="row">
                <div className="col-sm-12 col-md-12">
                    {/* <div style={{width: '250px', margin:"0 auto" }} className="mt-3">
                    <CircularProgressbar
                            value={affordableHomeValue !== null ? affordableHomeValue : 0}
                            strokeWidth={15}
                            styles={{
                                path: { stroke: '#AB1331' },
                                trail: { stroke: '#eee' },
                                text: { fontSize: '8px', fill: '#333' },
                            }}
                            text={
                                affordableHomeValue !== null ? (
                                    <>
                                        <tspan x="50%" dy="-10">Home Value</tspan>
                                        <tspan x="50%" dy="20">${affordableHomeValue.toLocaleString()}</tspan>
                                    </>
                                ) : 'N/A'
                            }
                        />
                    </div> */}
                    <div style={{ width: '250px', margin: "0 auto" }} className="mt-3">
                        <CircularProgressbar
                            value={loanPercentage}
                            strokeWidth={15}
                            styles={buildStyles({
                                pathColor: '#AB1331',  // Red for loan amount
                                trailColor: '#28A745',  // Green for down payment
                                textColor: '#333',
                                textSize: '8px'
                            })}
                            text={`$${affordableHomeValue !== null ? affordableHomeValue.toLocaleString() : 0}`}
                        />
                    </div>
                    <div className="d-flex flex-row justify-content-between mt-2">
                        <div>
                            <p className='text-amount1 mt-2 mx-3'>Loan Amount</p>
                            <p className='text-amount1 mt-2 mx-3'>Down Payment</p>
                            <p className='text-amount1 mt-2 mx-3'>Monthly Payment</p>
                        </div>
                        <div>
                            <input type="text" className="calculator-text1" value={loanAmount !== null ? loanAmount : 0}/>
                            <br/>
                            <input type="text" className="calculator-text1" value={downPayment}/>
                            <br/>
                            <input type="text" className="calculator-text1" value={monthlyPayment !== null ? monthlyPayment : 0}/>
                        </div>
                    </div>
                    {/* <Table className="table table-responsive table-bordered mt-5">
                        <tbody>
                            <tr>
                                <td><span className='text-amount1'>Loan Amount</span></td>
                                <td><p className='text-amount1'>{loanAmount !== null ? loanAmount : 0}</p></td>
                            </tr>
                            <tr>
                                <td><span className='text-amount1'>Down Payment</span></td>
                                <td><p className='text-amount1'>{downPayment}</p></td>
                            </tr>
                            <tr>
                                <td><span className='text-amount1'>Monthly Payment</span></td>
                                <td><p className='text-amount1'>{monthlyPayment !== null ? monthlyPayment : 0}</p></td>
                            </tr>
                        </tbody>
                    </Table> */}
                </div>
            </div>
            
        </>
    );
}

export default Affordabilitynav;
