import React from 'react'

const Getquotations = ({quotes}) => {
    console.log(quotes)
  return (
    <div>
      {quotes}
    </div>
  )
}

export default Getquotations
